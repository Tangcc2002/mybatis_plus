create
    definer = root@localhost procedure test(IN num int, IN num1 int, OUT num2 int)
begin
set num2 = 10;
end;

