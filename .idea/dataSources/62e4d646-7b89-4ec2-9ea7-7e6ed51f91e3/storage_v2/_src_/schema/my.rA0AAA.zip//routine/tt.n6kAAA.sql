create
    definer = root@localhost function tt() returns int no sql
begin
	set @a = (select id from user where id =1 );
	return @a;
end;

